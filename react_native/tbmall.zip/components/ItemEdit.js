import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  TextInput, 
  TouchableOpacity, 
  StyleSheet, 
  ScrollView,
  Alert,
  ActivityIndicator 
} from 'react-native';
import axios from 'axios';
import { useNavigation, useRoute } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';

function ItemEdit() {
  const navigation = useNavigation();
  const route = useRoute();
  const { itemId } = route.params;
  const [loading, setLoading] = useState(true);
  const [item, setItem] = useState({
    item_name: '',
    item_price: '',
    item_stock: '',
    item_description: '',
    image_url: ''
  });

  useEffect(() => {
    loadItemDetails();
  }, []);

  const loadItemDetails = async () => {
    try {
      const response = await axios.get(`/stuff/item/detail/${itemId}`);
      setItem(response.data);
      setLoading(false);
    } catch (error) {
      console.error('상품 정보 로딩 실패:', error);
      Alert.alert('오류', '상품 정보를 불러오는데 실패했습니다.');
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    try {
      const adminNo = await AsyncStorage.getItem('member_no');
      if (!adminNo) {
        Alert.alert('오류', '관리자 권한이 필요합니다.');
        return;
      }

      const formData = new FormData();
      Object.keys(item).forEach(key => {
        if (item[key]) {
          formData.append(key, item[key]);
        }
      });
      formData.append('admin_no', adminNo);
      formData.append('item_id', itemId);

      const response = await axios.post('/stuff/item/edit', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });

      if (response.data.success) {
        Alert.alert('성공', '물건이 수정되었습니다.', [
          { text: 'OK', onPress: () => navigation.navigate('ItemList') }
        ]);
      } else {
        Alert.alert('실패', response.data.message || '물건 수정에 실패했습니다.');
      }
    } catch (error) {
      console.error('Error:', error);
      Alert.alert('오류', '물건 수정 중 오류가 발생했습니다.');
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0000ff" />
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.formContainer}>
        <Text style={styles.title}>물건 수정</Text>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>물건 이름</Text>
          <TextInput
            style={styles.input}
            value={item.item_name}
            onChangeText={(text) => setItem(prev => ({
              ...prev,
              item_name: text
            }))}
          />
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>가격</Text>
          <TextInput
            style={styles.input}
            value={item.item_price?.toString()}
            onChangeText={(text) => setItem(prev => ({
              ...prev,
              item_price: text
            }))}
            keyboardType="numeric"
          />
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>재고</Text>
          <TextInput
            style={styles.input}
            value={item.item_stock?.toString()}
            onChangeText={(text) => setItem(prev => ({
              ...prev,
              item_stock: text
            }))}
            keyboardType="numeric"
          />
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>설명</Text>
          <TextInput
            style={styles.textArea}
            value={item.item_description}
            onChangeText={(text) => setItem(prev => ({
              ...prev,
              item_description: text
            }))}
            multiline
            numberOfLines={4}
          />
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>이미지 URL</Text>
          <TextInput
            style={styles.input}
            value={item.image_url}
            onChangeText={(text) => setItem(prev => ({
              ...prev,
              image_url: text
            }))}
          />
        </View>

        <View style={styles.buttonGroup}>
          <TouchableOpacity 
            style={styles.submitButton}
            onPress={handleSubmit}
          >
            <Text style={styles.buttonText}>수정</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.cancelButton}
            onPress={() => navigation.goBack()}
          >
            <Text style={styles.buttonText}>취소</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  formContainer: {
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  inputGroup: {
    marginBottom: 15,
  },
  label: {
    fontSize: 16,
    marginBottom: 5,
    fontWeight: '500',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
  },
  textArea: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    minHeight: 100,
    textAlignVertical: 'top',
  },
  buttonGroup: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 10,
    marginTop: 20,
  },
  submitButton: {
    backgroundColor: '#4CAF50',
    padding: 15,
    borderRadius: 8,
    width: '40%',
    alignItems: 'center',
  },
  cancelButton: {
    backgroundColor: '#f44336',
    padding: 15,
    borderRadius: 8,
    width: '40%',
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});

export default ItemEdit; 