// 서버 설정
export const SERVER_URL = 'http://192.168.0.148:8080';
export const API_BASE_URL = 'http://192.168.0.148:8080/mvc';
export const CLIENT_URL = 'http://192.168.0.148:3000'; 