package com.spring.service;

public class ipconfig {

}
