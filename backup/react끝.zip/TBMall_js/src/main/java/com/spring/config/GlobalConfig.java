package com.spring.config;

public class GlobalConfig {
	public static final String ALLOWED_ORIGIN = "http://192.168.0.148:3000";
	public static final String SERVER_IP = "192.168.0.148";
}