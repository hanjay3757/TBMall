// 서버 설정
export const SERVER_URL = 'http://192.168.0.128:8080';
export const API_BASE_URL = `${SERVER_URL}/mvc`;
export const CLIENT_URL = 'http://192.168.0.128:3000'; 