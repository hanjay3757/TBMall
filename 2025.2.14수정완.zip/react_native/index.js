import { registerRootComponent } from "expo";
import App from "./App";

// 앱의 진입점을 등록
registerRootComponent(App);
